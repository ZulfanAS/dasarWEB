<?php
    session_start();
    session_destroy();

    echo "you have successfully logged out";
    ?>