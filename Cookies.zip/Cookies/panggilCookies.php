<?php
echo $_COOKIE ["Mahasiswa"];
echo "<br>";
echo $_COOKIE ["Kelas"];

?>