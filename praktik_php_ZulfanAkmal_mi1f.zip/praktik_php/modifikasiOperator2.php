<html>
	<head>
	</head>
	<body>
		<?php
			$a =12;
			$b =14;
			echo "$a -= $b adalah "; var_dump ($a -= $b);
			echo "<br> $a > $b adalah "; var_dump ($a *= $b);
			echo "<br> $a == $b adalah "; var_dump ($a /= $b);
			echo "<br> $a!= $b adalah "; var_dump ($a %= $b);
            echo "<br> $a!= $b adalah "; var_dump ($a %= $b);
		?>
	</body>
</html>