<!DOCTYPE HTML>
<html>
    <head>
    </head>
    <body>
        <?php
        $hello = "hello world";
        echo $hello;
        ?>
    </body>
</html>