<!DOCTYPE HTML>
    <html>
    <head>
    </head>
        <body>
            <p> Kalimat dengan menggunakan HTML </p>
            <?php
            echo "kalimat dengan menggunakan PHP";
            ?>

        </body>
    
    </html>