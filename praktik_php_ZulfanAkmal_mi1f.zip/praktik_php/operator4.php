<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
        <?php 
        $x = 4;
        $x +=  3;
        echo "hasil operasi tersebut adalah =  $x";
        ?>
    </body>
</html>