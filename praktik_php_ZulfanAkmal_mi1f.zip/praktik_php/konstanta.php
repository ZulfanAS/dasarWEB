<!DOCTYPE html>
<html>
    <head>
    </head>
        <body>
            <?php 
            $var = "ini adalah contoh variabel";
            echo $var;
            echo "<br><br>";
            define ("konstanta","ini adalah contoh kosntanta", true );
            echo konstanta;
            echo "<br>";
            echo KONSTATA;
            ?>
        </body>
    
</html>